﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GemueseUndObstSoftware_Simple
{
    class Article
    {
        public int ArticleNumber;
        public string ArticleDescription;
        public decimal Price;
        public decimal StorageQuantity;
        public QuantityUnit QuantityUnit;
        public Article()
        {

        }

        public Article(int articleNumber, string articleDescription, QuantityUnit quantityUnit, decimal price)
        {
            this.ArticleNumber = articleNumber;
            this.ArticleDescription = articleDescription;
            this.QuantityUnit = quantityUnit;
            this.Price = price;
        }

        public override string ToString()
        {
            string returner = $"{ArticleNumber}î{ArticleDescription}î{Price}î{StorageQuantity}î{QuantityUnit}";
            return returner;
        }
    }
}
