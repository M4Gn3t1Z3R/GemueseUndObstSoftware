﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GemueseUndObstSoftware_Simple
{
    public enum QuantityUnit
    {
        kg,
        piece,
        liter
    }
}
