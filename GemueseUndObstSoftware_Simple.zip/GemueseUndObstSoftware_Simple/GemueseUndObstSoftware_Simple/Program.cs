﻿using System;
using System.IO;
using System.Linq;

namespace GemueseUndObstSoftware_Simple
{
    class Program
    {

        private static readonly string DataLocation = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GemueseUndObstApplicationData");
        private static readonly string AppDataFile = Path.Combine(DataLocation, "AppData.data");
        private static readonly string ArticleDataLocation = Path.Combine(DataLocation, "Articles");
        static void Main(string[] args)
        {
            Storage storage = new Storage();
            Console.OutputEncoding = System.Text.Encoding.Default;
            bool autosave = true;
            LoadAll(storage, ref autosave);
            bool executeProgram = true;
            do
            {
                Console.Clear();
                Console.WriteLine("Bitte Operation auswählen");
                Console.WriteLine(@$"
1 - Artikel erstellen
2 - Artikel löschen

3 - Ausbuchen
4 - Einbuchen

5 - Preis ändern

S - Speichern
A - Autospeichern Präferenzen bearbeiten {(autosave?"(aktiviert)":"(deaktiviert)")}

X - Programm beenden
");
                Console.WriteLine();
                string input = Console.ReadLine();
                Console.Clear();
                if(input.ToLower() != "a" && input.ToLower() != "s" && input.ToLower() != "x")
                {
                    Console.WriteLine("Artikel im Lager:");
                    foreach (Article article in storage.ArticleStock)
                    {
                        Console.WriteLine($"Nr.{article.ArticleNumber}, {article.ArticleDescription}, zu je {article.Price}€/{(article.QuantityUnit == QuantityUnit.piece? "Stück" : article.QuantityUnit.ToString())}, Lager enthält {article.StorageQuantity} {(article.QuantityUnit == QuantityUnit.piece ? "Stück" : article.QuantityUnit.ToString())}");
                    }
                }
                
                Console.WriteLine();
                switch (input)
                {
                    case "1":
                        CreateArticle(storage, autosave);
                        break;
                    case "2":
                        DeleteArticle(storage);
                        break;
                    case "3":
                        BookOut(storage, autosave);
                        break;
                    case "4":
                        BookIn(storage, autosave);
                        break;
                    case "5":
                        ChangePrice(storage, autosave);
                        break;
                    case "a":
                    case "A":
                        Console.WriteLine();
                        Console.WriteLine(@$"Soll die Präferenz zum Autospeichern verändert werden?
1 - Autospeichern aktivieren
2 - Autospeichern deaktivieren");
                        input = Console.ReadLine();
                        Console.WriteLine();
                        if(input == "1")
                        {
                            autosave = true;
                            File.WriteAllText(AppDataFile, true.ToString());
                            Console.WriteLine("Autospeichern wurde aktiviert");
                        }
                        else if( input == "2")
                        {
                            autosave = false;
                            File.WriteAllText(AppDataFile, false.ToString());
                            Console.WriteLine("Autospeichern wurde deaktiviert");
                        }
                        else
                        {
                            Console.WriteLine("Dies ist keine gültige eingabe!");
                        }
                        break;
                    case "s":
                    case "S":
                        SaveAll(storage, autosave);
                        break;
                    case "x":
                    case "X":
                        executeProgram = false;
                        break;
                    default:
                        Console.WriteLine();
                        Console.WriteLine("Dies ist keine gültige Eingabe!");
                        break;
                }
                if (!executeProgram)
                    break;
                Console.WriteLine();
                Console.WriteLine("\nEscape Taste ==> Beenden\nBeliebige andere Taste ==> Fortsetzen");
                if (Console.ReadKey().Key == ConsoleKey.Escape)
                    break;
            } while (executeProgram);
        }

        public static void BookOut(Storage storage, bool autosave)
        {
            bool successful = true;
            do
            {
                Console.WriteLine("Bitte geben sie die Artikelnummer ein, von der ausgebucht werden soll");
                string input = Console.ReadLine();
                if (int.TryParse(input, out int articleNumber) && storage.ArticleStock.Any(a => a.ArticleNumber == articleNumber))
                {
                    Console.WriteLine();
                    Console.WriteLine("Bitte geben sie die Menge ein, die ausgebucht werden soll");
                    input = Console.ReadLine();
                    if (decimal.TryParse(input, out decimal quantity) && quantity >= 0)
                    {
                        if (storage.ArticleStock.Single(a => a.ArticleNumber == articleNumber).StorageQuantity < quantity)
                        {
                            successful = false;
                            break;
                        }
                        storage.BookOut(quantity, articleNumber);
                        Console.WriteLine();
                        Console.WriteLine("Erfolgreich ausgebucht");
                        if (autosave)
                            SaveOneArticle(storage.ArticleStock.Single(a => a.ArticleNumber == articleNumber));
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Dies ist keine gültige Zahl");
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Dies ist keine gültige Zahl oder der Artikel existiert nicht");
                }
            } while (false);
            if (!successful)
            {
                Console.WriteLine("Fehler beim Ausbuchen");
            }
        }
        public static void BookIn(Storage storage, bool autosave)
        {
            Console.WriteLine("Bitte geben sie die Artikelnummer ein, von der eingebucht werden soll");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int articleNumber))
            {
                Console.WriteLine();
                Console.WriteLine("Bitte geben sie die Menge ein, die eingebucht werden soll");
                input = Console.ReadLine();
                if (decimal.TryParse(input, out decimal quantity) && quantity >= 0)
                {
                    storage.BookIn(quantity,articleNumber);
                    Console.WriteLine();
                    Console.WriteLine("Erfolgreich eingebucht");
                    if(autosave)
                        SaveOneArticle(storage.ArticleStock.Single(a => a.ArticleNumber == articleNumber));
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Dies ist keine gültige Zahl");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Dies ist keine gültige Zahl");
            }
        }
        public static void CreateArticle(Storage storage, bool autosave)
        {
            Console.WriteLine("Bitte geben sie die Artikel Nummer des zu erstellenden Artikels ein");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int articleNumber) && !storage.ArticleStock.Any(a => a.ArticleNumber == articleNumber) && articleNumber >= 0)
            {
                Console.WriteLine();
                Console.WriteLine("Bitte geben sie die Artikel Beschreibung (Inklusive Name) ein");
                string articleDescription = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine("Bitte geben sie die Mengeneinheit an, mit der der Artikel gehandelt werden soll");
                Console.WriteLine(@"
1 - kg
2 - stück
3 - liter
");
                input = Console.ReadLine();
                QuantityUnit quantityUnit = QuantityUnit.kg;
                switch (input)
                {
                    case "1":
                        quantityUnit = QuantityUnit.kg;
                        break;
                    case "2":
                        quantityUnit = QuantityUnit.piece;
                        break;
                    case "3":
                        quantityUnit = QuantityUnit.liter;
                        break;
                    default:
                        Console.WriteLine("Dies ist keine gültige Zahl!");
                        return;
                }
                Console.WriteLine();
                Console.WriteLine("Bitte geben sie den Preis des Artikels ein");
                input = Console.ReadLine();
                if(decimal.TryParse(input, out decimal price))
                {
                    storage.CreateArticle(articleNumber, articleDescription, quantityUnit, price);
                    if(autosave)
                        SaveOneArticle(storage.ArticleStock.Single(a => a.ArticleNumber == articleNumber));
                }
            }
            else
            {
                Console.WriteLine("Dies ist keine gültige Zahl oder es gibt bereits einen Artikel mit dieser Zahl");
            }
        }
        public static void ChangePrice(Storage storage, bool autosave)
        {
            Console.WriteLine("Bitte geben sie die Artikel Nummer ein, von der der Preis verändert werden soll");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int articleNumber))
            {
                Console.WriteLine();
                Console.WriteLine("Bitte geben sie den neuen Preis ein, unter dem die Ware gehandelt werden soll");
                input = Console.ReadLine();
                if(decimal.TryParse(input, out decimal newPrice))
                {
                    storage.ChangePrice(articleNumber, newPrice);
                    if(autosave)
                        SaveOneArticle(storage.ArticleStock.Single(a => a.ArticleNumber == articleNumber));
                }
                else
                {
                    Console.WriteLine("Dies ist keine gültige Preis Angabe");
                }
            }
            else
            {
                Console.WriteLine("Dies ist keine gültige Zahl");
            }
        }
        public static void DeleteArticle(Storage storage)
        {
            Console.WriteLine("Bitte geben sie die Artikelnummer ein, die gelöscht werden soll");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int articleNumber))
            {
                storage.DeleteArticle(articleNumber);
                if(File.Exists(Path.Combine(ArticleDataLocation, articleNumber + ".article"))){
                    File.Delete(Path.Combine(ArticleDataLocation, articleNumber + ".article"));
                }
            }
            else
            {
                Console.WriteLine("Dies ist keine gltige Zahl");
            }
        }
        public static void SaveAll(Storage storage, bool autosave)
        {
            File.WriteAllText(AppDataFile, autosave.ToString(), System.Text.Encoding.UTF7);
            foreach(Article article in storage.ArticleStock)
            {
                SaveOneArticle(article);
            }
        }

        public static void SaveOneArticle(Article article)
        {
            File.WriteAllText(Path.Combine(ArticleDataLocation, article.ArticleNumber.ToString() + ".article"), article.ToString(), System.Text.Encoding.UTF7);
        }

        public static void LoadAll(Storage storage, ref bool autosave)
        {
            if (!Directory.Exists(ArticleDataLocation))
            {
                Directory.CreateDirectory(ArticleDataLocation);
            }
            if (!File.Exists(AppDataFile)){
                File.Create(AppDataFile);
            }
            else
            {
                string dataContent = File.ReadAllText(AppDataFile, System.Text.Encoding.UTF7);
                bool.TryParse(dataContent, out autosave);
            }
            foreach(var file in Directory.GetFiles(ArticleDataLocation))
            {
                Article loadedArticle = LoadOneArticle(file);
                storage.ArticleStock.Add(loadedArticle);
            }
        }

        public static Article LoadOneArticle(string fileName)
        {
            string content = File.ReadAllText(fileName, System.Text.Encoding.UTF7);
            string[] splitContent = { };
            if (content.Contains('î'))
            {
                splitContent = content.Split('î');
            }
            else if (content.Contains('�'))
            {
                splitContent = content.Split('�');
            }
            Article returner = new Article();
            returner.ArticleNumber = int.Parse(splitContent[0]);
            returner.ArticleDescription = splitContent[1];
            returner.Price = decimal.Parse(splitContent[2]);
            returner.StorageQuantity = decimal.Parse(splitContent[3]);
            returner.QuantityUnit = (QuantityUnit) Enum.Parse(typeof(QuantityUnit), splitContent[4]);
            return returner;
            //$"{ArticleNumber}î{ArticleDescription}î{Price}î{StorageQuantity}î{QuantityUnit}"
        }
    }
}
