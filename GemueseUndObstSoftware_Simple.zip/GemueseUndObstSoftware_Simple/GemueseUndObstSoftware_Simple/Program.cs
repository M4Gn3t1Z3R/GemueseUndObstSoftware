﻿using System;
using System.IO;

namespace GemueseUndObstSoftware_Simple
{
    class Program
    {

        private static readonly string DataLocation = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GemueseUndObstApplicationData");
        private static readonly string ArticleDataLocation = Path.Combine(DataLocation, "Articles");
        static void Main(string[] args)
        {
            Storage storage = new Storage();
            bool executeProgram = true;
            do
            {
                Console.WriteLine("Bitte Operation auswählen");
                Console.WriteLine(@$"
1 - Artikel erstellen
2 - Artikel löschen

3 - Ausbuchen
4 - Einbuchen

5 - Preis ändern
");
                string input = Console.ReadLine();
                Console.Clear();
                switch (input)
                {
                    case "1":
                        break;
                    case "2":
                        break;
                    case "3":
                        break;
                    case "4":
                        break;
                    case "5":
                        break;
                    default:
                        Console.WriteLine("Dies ist keine gültige Eingabe!");
                        break;
                }
                Console.WriteLine();
            } while (executeProgram);
        }

        public static void BookOut(Storage storage)
        {
            Console.WriteLine("Bitte geben sie die Artikelnummer ein, von der ausgebucht werden soll");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int articleNumber))
            {
                Console.WriteLine("Bitte geben sie die Menge ein, die ausgebucht werden soll");
                input = Console.ReadLine();
                if(decimal.TryParse(input, out decimal quantity))
                {
                    storage.BookOut(quantity, articleNumber);
                    Console.WriteLine("Erfolgreich ausgebucht");
                }
                else
                {
                    Console.WriteLine("Dies ist keine gültige Zahl");
                }
            }
            else
            {
                Console.WriteLine("Dies ist keine gültige Zahl");
            }
        }
        public static void BookIn(Storage storage)
        {
            Console.WriteLine("Bitte geben sie die Artikelnummer ein, von der eingebucht werden soll");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int articleNumber))
            {
                Console.WriteLine("Bitte geben sie die Menge ein, die eingebucht werden soll");
                input = Console.ReadLine();
                if (decimal.TryParse(input, out decimal quantity))
                {
                    storage.BookIn(quantity, articleNumber);
                    Console.WriteLine("Erfolgreich eingebucht");
                }
                else
                {
                    Console.WriteLine("Dies ist keine gültige Zahl");
                }
            }
            else
            {
                Console.WriteLine("Dies ist keine gültige Zahl");
            }
        }
        public static void CreateArticle(Storage storage)
        {
            Console.WriteLine("Bitte geben sie die Artikel Nummer ein des zu erstellenden Artikels");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int articleNumber))
            {
                Console.WriteLine("Bitte geben sie die Artikel Beschreibung (Inklusive Name) ein");
                string articleDescription = Console.ReadLine();
                Console.WriteLine("Bitte geben sie die Mengeneinheit an, mit der der Artikel gehandelt werden soll");
                Console.WriteLine(@"
1 - kg
2 - stück
3 - liter
");
                input = Console.ReadLine();
                QuantityUnit quantityUnit = QuantityUnit.kg;
                switch (input)
                {
                    case "1":
                        quantityUnit = QuantityUnit.kg;
                        break;
                    case "2":
                        quantityUnit = QuantityUnit.piece;
                        break;
                    case "3":
                        quantityUnit = QuantityUnit.liter;
                        break;
                    default:
                        Console.WriteLine("Dies ist keine gültige Zahl!");
                        return;
                }
                Console.WriteLine("Bitte geben sie den Preis des Artikels ein");
                input = Console.ReadLine();
                if(decimal.TryParse(input, out decimal price))
                {
                    storage.CreateArticle(articleNumber, articleDescription, quantityUnit, price);
                }
            }
            else
            {
                Console.WriteLine("Dies ist keine gültige Zahl");
            }
        }
        public static void ChangePrice(Storage storage)
        {
            Console.WriteLine("Bitte geben sie die Artikel Nummer ein, von der der Preis verändert werden soll");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int articleNumber))
            {
                Console.WriteLine("Bitte geben sie den neuen Preis ein, unter dem die Ware gehandelt werden soll");
                input = Console.ReadLine();
                if(decimal.TryParse(input, out decimal newPrice))
                {
                    storage.ChangePrice(articleNumber, newPrice);
                }
                else
                {
                    Console.WriteLine("Dies ist keine gültige Preis Angabe");
                }
            }
            else
            {
                Console.WriteLine("Dies ist keine gültige Zahl");
            }
        }
        public static void DeleteArticle(Storage storage)
        {
            Console.WriteLine("Bitte geben sie dei Artikelnummer ein, die gelöscht werden soll");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int articleNumber))
            {
                storage.DeleteArticle(articleNumber);
            }
            else
            {
                Console.WriteLine("Dies ist keine gltige Zahl");
            }
        }
        public static void SaveAll(Storage storage)
        {
            foreach(Article article in storage.ArticleStock)
            {
                SaveOneArticle(article);
            }
        }

        public static void SaveOneArticle(Article article)
        {
            File.WriteAllText(Path.Combine(ArticleDataLocation, article.ArticleNumber.ToString()), article.ToString());
        }

        public static void LoadAll(Storage storage)
        {
            foreach(var file in Directory.GetFiles(ArticleDataLocation))
            {
                Article loadedArticle = LoadOneArticle(file);
                storage.ArticleStock.Add(loadedArticle);
            }
        }

        public static Article LoadOneArticle(string fileName)
        {
            string content = File.ReadAllText(fileName);
            string[] splitContent = content.Split('î');
            Article returner = new Article();
            returner.ArticleNumber = int.Parse(splitContent[0]);
            returner.ArticleDescription = splitContent[1];
            returner.Price = decimal.Parse(splitContent[2]);
            returner.StorageQuantity = decimal.Parse(splitContent[3]);
            returner.QuantityUnit = (QuantityUnit) Enum.Parse(typeof(QuantityUnit), splitContent[4]);
            return returner;
            //$"{ArticleNumber}î{ArticleDescription}î{Price}î{StorageQuantity}î{QuantityUnit}"
        }
    }
}
