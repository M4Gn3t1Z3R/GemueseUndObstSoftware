﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GemueseUndObstSoftware_Simple
{
    class Storage
    {
        public List<Article> ArticleStock;

        public Storage()
        {
            ArticleStock = new List<Article>();
        }

        public void BookOut(decimal quantity, int articleNumber)
        {
            try
            {
                ArticleStock.Single(a => a.ArticleNumber == articleNumber).StorageQuantity -= ArticleStock.Single(a => a.ArticleNumber == articleNumber).StorageQuantity - quantity < 0 ? 0: quantity;
            }
            catch (Exception e)
            {
                Console.WriteLine("diese Artikelnummer existiert nicht");
            }
        }
        public void BookIn(decimal quantity, int articleNumber)
        {
            try 
            { 
                ArticleStock.Single(a => a.ArticleNumber == articleNumber).StorageQuantity += quantity;
            }
            catch (Exception e)
            {
                Console.WriteLine("diese Artikelnummer existiert nicht");
            }
        }
        public void CreateArticle(int articleNumber, string articleDescription, QuantityUnit quantityUnit, decimal price)
        {
            if(ArticleStock.Any(a => a.ArticleNumber == articleNumber))
            {
                Console.WriteLine("Diese Artikelnummer existiert bereits");
            }
            else
            {
                ArticleStock.Add(new Article( articleNumber,  articleDescription,  quantityUnit,  price));
            }
        }
        public void ChangePrice(int articleNumber, decimal newPrice)
        {
            try
            {
                ArticleStock.Single(a => a.ArticleNumber == articleNumber).Price = newPrice;
            }
            catch (Exception e)
            {
                Console.WriteLine("diese Artikelnummer existiert nicht");
            }
        }
        public void DeleteArticle(int articleNumber)
        {
            try
            {
                ArticleStock.Remove(ArticleStock.Single(a => a.ArticleNumber == articleNumber));
            }
            catch(Exception e)
            {
                Console.WriteLine("diese Artikelnummer existiert nicht");
            }
        }
        public decimal GetAmountOfArticle(int articleNumber)
        {
            return ArticleStock.Single(a => a.ArticleNumber == articleNumber).StorageQuantity;
        }
    }
}
